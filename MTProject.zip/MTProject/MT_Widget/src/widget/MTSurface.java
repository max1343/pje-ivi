package widget;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import tuio.*;

public class MTSurface extends JPanel {
	
	public MTSurface() {
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		// drawing instructions with g2.
	}

}
